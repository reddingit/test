waxClass{"YH_GuangMainVC", UIViewController}
function viewDidLoad(self)
--before do something
     self:ORIGviewDidLoad()--self is no need
--after do something
    print('YH_GuangMainVC');
	local alert = UIAlertView:init();
	alert:setTitle(title);
	alert:setMessage("aaaa");
	alert:setTitle("home");
	alert:setDelegate(self);
	alert:addButtonWithTitle("cancel");
	alert:addButtonWithTitle("ok");
	alert:setTag(20147701);
	alert:show();
end