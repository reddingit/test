waxClass{"YH_PlusStarViewController", UIViewController}
function viewDidLoad(self)
--before do something
     self:ORIGviewDidLoad()--self is no need
--after do something
	local alert = UIAlertView:init();
	alert:setTitle(title);
	alert:setMessage("bbbb");
	alert:setTitle("watch");
	alert:setDelegate(self);
	alert:addButtonWithTitle("cancel");
	alert:addButtonWithTitle("ok");
	alert:setTag(20147701);
	alert:show();
end